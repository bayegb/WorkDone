#include <iostream>

#ifndef _COUNTING_H
#define _COUNTING_H

#include <vector>
#include <fstream>

namespace FLLBAY001{
	
	std::vector<int> count(std::ifstream& inputFile);
}

#endif
