C++ Assignment 1
Author: Baye-Saliou Fall

Note the following :

1. There is a text file called "file.txt", that is used as input file. The contents of it can be changed accordingly. 

2. The executable runs with the following command ("file.txt" is input file and "CountingDriver.exe" is the executable file):
	
	cat file.txt | ./CountingDriver.exe

3. All the files are in one directory.